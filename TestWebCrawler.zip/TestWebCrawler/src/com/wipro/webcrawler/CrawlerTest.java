package com.wipro.webcrawler;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Scanner;
import org.junit.Assert;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * 
 * @class name: CrawlerTest
 * Description : Test the WebCrawler through Junit test class. Provide input as url and file name
 */
class CrawlerTest {
       
       WebCrawler crawler = new WebCrawler();
       private String url = null;
       private String fileName = null;
 
       @BeforeEach
       void setUp() throws Exception {
              Scanner sc = new Scanner(System.in);
              System.out.println("enter the website url");
              url = sc.nextLine();
              System.out.println("enter the filename ");
              fileName = sc.nextLine();
       }
 
       @Test
       void test() throws Exception {
              crawler.webCrawl(url, fileName);
              BufferedReader reader = new BufferedReader(new FileReader(new File(fileName)));
              String currentLine = reader.readLine();
              Assert.assertTrue(currentLine.length()>0);
       }
       
       @AfterEach
       void tearDown() throws Exception {
              crawler = null;
              url = null;
              fileName = null;
       }
 
}