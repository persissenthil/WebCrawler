package com.wipro.webcrawler;
 
import java.io.BufferedInputStream;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

 /**
   * @class name: WebCrawler.java
   * Date:12/17/2018
   * Description: Webcrawler for url https://wiprodigital.com/ 
   */
public class WebCrawler {
       
       	
       public void webCrawl(String inputUrl, String filename) { // passed url and filename as parameter
              try {
                     
                 URL url;
                  InputStream is = null;
                  DataInputStream dis;
                  String line;
                  BufferedWriter writer = null;
 
                  try {
                      url = new URL(inputUrl);
                      is = url.openStream(); 
                      dis = new DataInputStream(new BufferedInputStream(is));
                      writer = new BufferedWriter(new FileWriter(filename,true));
                        while ((line = dis.readLine()) != null) {
                           final String regex4 = "\\b" + inputUrl + ".+";
                           Pattern pattern = Pattern.compile(regex4);
                            Matcher matcher = pattern.matcher(line);
                                  while (matcher.find()) {
                                         String s = matcher.group();
                                         System.out.println("site added for crawling " + s);
                                         writer.append(s);
                                         writer.append("\n");
                                  }
                      }
                  } catch (MalformedURLException mue) {
                      mue.printStackTrace();
                  } catch (IOException ioe) {
                      ioe.printStackTrace();
                  } finally {
                      try {
                          is.close();
                          writer.close();
                      } catch (IOException ioe) {
                          // nothing to see here
                      }
                  }
              }catch(Exception e) {
                     
              }
       }
       
       public static void main(String[] args) {
              WebCrawler obj = new WebCrawler();
              obj.webCrawl("https://wiprodigital.com/", "file.txt");
       }
       
}
 
 